#define _VIV_ZOOM_MAX 1024
#define _VIV_ZOOM_SHRINK_STEPS 278
#define _VIV_ZOOM_STEPS_PER_NOTCH 10
enum
{
	_VIV_DOING_NOTHING,
	_VIV_DOING_SCROLL,
	_VIV_DOING_MSCROLL,
	_VIV_DOING_1TO1SCROLL,
};
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint32_t DWORD;
typedef unsigned char BYTE;
typedef void *HWND;
typedef long long __int64;
typedef struct { int left, top, right, bottom; } RECT;
typedef struct { int x, y; } POINT;
typedef struct {
    unsigned cbSize, dwFlags, dwID;
    struct { short x, y; } ptsLocation;
    uint64_t ullArguments;
} os_GestureInfo_t;
#define FALSE 0
#define SM_CXVIRTUALSCREEN 78
#define SM_CYVIRTUALSCREEN 79
static int os_logical_wide = 96, _viv_1to1, _viv_zoom_pos;
static int _viv_view_x, _viv_view_y, _viv_doing, captured;
static int _viv_is_fullscreen, config_fullscreen_fill_window, config_fill_window;
static int config_keep_aspect_ratio = 1, config_allow_shrinking = 1;
static struct { int image_wide, image_high; } _viv_slot_current;
static float _viv_zoom_scales[_VIV_ZOOM_MAX];
static int client_wide = 1600, client_high = 1000;
static HWND _viv_hwnd;
static int closed, invalidated, status_updates, navigated;
static uintptr_t message_extra;
static os_GestureInfo_t next_info;
static int get_info(void *handle, os_GestureInfo_t *info) { *info = next_info; return 1; }
static int close_info(void *handle) { closed++; return 1; }
static int (*os_GetGestureInfo)(void *, os_GestureInfo_t *) = get_info;
static int (*os_CloseGestureInfoHandle)(void *) = close_info;
static int GetSystemMetrics(int which) { return 4096; }
static uintptr_t GetMessageExtraInfo(void) { return message_extra; }
static int GetClientRect(HWND hwnd, RECT *rect) { *rect = (RECT){0, 0, client_wide, client_high}; return 1; }
static int ScreenToClient(HWND hwnd, POINT *point) { return 1; }
static void os_zero_memory(void *p, size_t size) { memset(p, 0, size); }
static int _viv_get_status_high(void) { return 0; }
static int _viv_get_view_top(void) { return 0; }
static void _viv_next(int prev, int reset, int preload, int wait) { navigated += prev ? -1 : 1; }
static void _viv_view_scroll(int x, int y) { _viv_view_x -= x; _viv_view_y -= y; }
static void _viv_view_set(int x, int y, int update) { _viv_view_x = x; _viv_view_y = y; }
static void InvalidateRect(HWND hwnd, void *rect, int erase) { invalidated++; }
static void _viv_status_update_temp_pos_zoom(void) { status_updates++; }
static void _viv_doing_cancel(void) { _viv_doing = captured = 0; }

static void init_scales(void)
{
		int i;
		double f;
		
		f = 1.0;
		
		for(i=0;i<_VIV_ZOOM_MAX;i++)
		{
			_viv_zoom_scales[i] = (float)f;
			
			f *= 1.01;
		}
	}
static double _viv_clamp_double(double value,double maximum)
{
	if (value > maximum)
	{
		return maximum;
	}
	
	return value;
}
void _viv_get_render_size(int *prw,int *prh)
{
	RECT rect;
	int wide;
	int high;
	int rw;
	int rh;
	int fill_window;
	
	if (!((_viv_slot_current.image_wide) && (_viv_slot_current.image_high)))
	{
		*prw = 0;
		*prh = 0;
		
		return;
	}
	
	GetClientRect(_viv_hwnd,&rect);
	wide = rect.right - rect.left;
	high = rect.bottom - rect.top - _viv_get_status_high() - _viv_get_view_top();
	
	if (!((wide) && (high)))
	{
		*prw = 0;
		*prh = 0;
		
		return;
	}

	if ((_viv_1to1) || (_viv_doing == _VIV_DOING_1TO1SCROLL))
	{
		*prw = _viv_slot_current.image_wide;
		*prh = _viv_slot_current.image_high;
		
		return;
	}
			
	if (_viv_is_fullscreen)
	{
		fill_window = config_fullscreen_fill_window;
	}
	else
	{
		fill_window = config_fill_window;
	}
	
	if (config_keep_aspect_ratio)
	{
		// the comparison rides the same 64-bit ceiling the real
		// arithmetic below rides: an int-times-int product overflows
		// on strip panoramas (a 95mp banner) and picks the wrong
		// branch before rw ever runs.
		if ((high * (__int64)_viv_slot_current.image_wide) / _viv_slot_current.image_high < wide)
		{
			// tall image.
			// add  _viv_slot_current.image_high - 1 so when we resize the window to 50% it stretches to the screen edges correctly.
			rh = high;
			rw = ((high * (__int64)_viv_slot_current.image_wide) + _viv_slot_current.image_high - 1) / _viv_slot_current.image_high;

			// make sure we have some width.			
			if (rw <= 0)
			{
				rw = 1;
			}
		}
		else
		{
			// long image.
			// add _viv_slot_current.image_wide - 1 so when we resize the window to 50% it stretches to the screen edges correctly.
			rw = wide;
			rh = ((wide * (__int64)_viv_slot_current.image_high) + _viv_slot_current.image_wide - 1) / _viv_slot_current.image_wide;

			// make sure we have some height	
			if (rh <= 0)
			{
				rh = 1;
			}
		}

		if (!fill_window)
		{
			if ((rw > _viv_slot_current.image_wide) || (rh > _viv_slot_current.image_high))
			{
				rw = _viv_slot_current.image_wide;
				rh = _viv_slot_current.image_high;
			}
		}
	}
	else
	{
		rw = wide;
		rh = high;

		if (!fill_window)
		{
			if (rw > _viv_slot_current.image_wide)
			{
				rw = _viv_slot_current.image_wide;
			}			
	
			if (rh > _viv_slot_current.image_high)
			{
				rh = _viv_slot_current.image_high;
			}
		}
	}

//	debug_printf("GET_RENDER_SIZE wide %d high %d rw %d rh %d fill_window %d\n",wide,high,rw,rh,fill_window);

	if (!config_allow_shrinking)
	{
		if (config_keep_aspect_ratio)
		{
			if ((rw < _viv_slot_current.image_wide) || (rh < _viv_slot_current.image_high))
			{
				rw = _viv_slot_current.image_wide;
				rh = _viv_slot_current.image_high;
			}
		}
		else
		{
			if (rw < _viv_slot_current.image_wide)
			{
				rw = _viv_slot_current.image_wide;
			}

			if (rh < _viv_slot_current.image_high)
			{
				rh = _viv_slot_current.image_high;
			}
		}
	}		
	
	// the zoom ladder is geometric: each step multiplies the best fit size
	// by 1.01. the ladder tops out at 16x the NATIVE image size per axis
	// (exactly 1600% on the status bar; deep zoom stays reachable for photos
	// much larger than the window), and the last reachable step snaps
	// exactly to the cap. the cap never drops below the pos 0 fit, so fill
	// window keeps its upscale (rc.7: the old 16x-the-LARGER rule let a
	// window larger than the image, or fill window, push the ceiling to
	// 16x the fit - the 2478% report).
	if (_viv_zoom_pos)
	{
		double scale;
		double max_w;
		double max_h;
		
		// the below-fit extension uses the reciprocal of the table entry
		// (1.01^-n is exactly 1/1.01^n), so negative positions never index
		// the scale table out of bounds.
		scale = (_viv_zoom_pos > 0) ? _viv_zoom_scales[_viv_zoom_pos] : (1.0 / _viv_zoom_scales[-_viv_zoom_pos]);
		
		// the caps are computed in double space: an int cap could itself
		// overflow for an absurd panorama.
		max_w = 16.0 * (double)_viv_slot_current.image_wide;
		max_h = 16.0 * (double)_viv_slot_current.image_high;
		
		// never shrink below the pos 0 size: the fill window upscale is a
		// layout decision, not a zoom level.
		if (max_w < (double)rw)
		{
			max_w = (double)rw;
		}
		
		if (max_h < (double)rh)
		{
			max_h = (double)rh;
		}
		
		rw = (int)_viv_clamp_double((double)rw * scale,max_w);
		rh = (int)_viv_clamp_double((double)rh * scale,max_h);
		
		// a deep below-fit zoom of a tiny image can round to a zero render
		// size: keep one pixel so the draw and view math never divide by
		// zero.
		if (rw < 1)
		{
			rw = 1;
		}
		
		if (rh < 1)
		{
			rh = 1;
		}
	}
	
	*prw = rw;
	*prh = rh;
}
static int _viv_zoom_pos_max_cache = -1;
static int _viv_zoom_pos_max_cache_image_wide = -1;
static int _viv_zoom_pos_max_cache_image_high = -1;
static int _viv_zoom_pos_max_cache_view_wide = -1;
static int _viv_zoom_pos_max_cache_view_high = -1;
static int _viv_zoom_pos_max_cache_fill_window = -1;
static int _viv_zoom_pos_max_cache_keep_aspect = -1;
static int _viv_zoom_pos_max_cache_allow_shrinking = -1;

int _viv_zoom_pos_max(void)
{
	RECT rect;
	int wide;
	int high;
	int fill_window;
	int rw;
	int rh;
	int pos;
	int max_pos;
	
	max_pos = 0;
	
	// build the dependency signature of the ladder top: the image, the
	// viewport and the layout settings. (the zoom position itself is not
	// part of it: the top is always measured with the zoom state cleared.)
	GetClientRect(_viv_hwnd,&rect);
	wide = rect.right - rect.left;
	high = rect.bottom - rect.top - _viv_get_status_high() - _viv_get_view_top();
	
	if (_viv_is_fullscreen)
	{
		fill_window = config_fullscreen_fill_window;
	}
	else
	{
		fill_window = config_fill_window;
	}
	
	if ((_viv_zoom_pos_max_cache >= 0)
		&& (_viv_zoom_pos_max_cache_image_wide == _viv_slot_current.image_wide)
		&& (_viv_zoom_pos_max_cache_image_high == _viv_slot_current.image_high)
		&& (_viv_zoom_pos_max_cache_view_wide == wide)
		&& (_viv_zoom_pos_max_cache_view_high == high)
		&& (_viv_zoom_pos_max_cache_fill_window == fill_window)
		&& (_viv_zoom_pos_max_cache_keep_aspect == config_keep_aspect_ratio)
		&& (_viv_zoom_pos_max_cache_allow_shrinking == config_allow_shrinking))
	{
		return _viv_zoom_pos_max_cache;
	}
	
	// measure the unzoomed best fit size with the zoom state cleared.
	{
		int backup_pos;
		int backup_1to1;
		int backup_doing;
		
		backup_pos = _viv_zoom_pos;
		backup_1to1 = _viv_1to1;
		backup_doing = _viv_doing;
		
		_viv_zoom_pos = 0;
		_viv_1to1 = 0;
		_viv_doing = _VIV_DOING_NOTHING;
		
		_viv_get_render_size(&rw,&rh);
		
		_viv_zoom_pos = backup_pos;
		_viv_1to1 = backup_1to1;
		_viv_doing = backup_doing;
	}
	
	if ((rw) && (rh))
	{
		double max_w;
		double max_h;
		
		// 16x native (1600%), never below the measured pos 0 fit (fill
		// window keeps its upscale): mirrors _viv_get_render_size.
		max_w = 16.0 * (double)_viv_slot_current.image_wide;
		max_h = 16.0 * (double)_viv_slot_current.image_high;
		
		if (max_w < (double)rw)
		{
			max_w = (double)rw;
		}
		
		if (max_h < (double)rh)
		{
			max_h = (double)rh;
		}
		
		// walk the ladder for the first position that hits the cap on
		// either axis.
		for(pos=0;pos<_VIV_ZOOM_MAX;pos++)
		{
			if (((double)rw * (double)_viv_zoom_scales[pos]) >= max_w)
			{
				break;
			}
			
			if (((double)rh * (double)_viv_zoom_scales[pos]) >= max_h)
			{
				break;
			}
		}
		
		if (pos < _VIV_ZOOM_MAX)
		{
			max_pos = pos;
		}
		else
		{
			max_pos = _VIV_ZOOM_MAX-1;
		}
	}
	else
	{
		// no image (or degenerate window): keep the full table range so
		// startup code paths are untouched.
		max_pos = _VIV_ZOOM_MAX-1;
	}
	
	_viv_zoom_pos_max_cache = max_pos;
	_viv_zoom_pos_max_cache_image_wide = _viv_slot_current.image_wide;
	_viv_zoom_pos_max_cache_image_high = _viv_slot_current.image_high;
	_viv_zoom_pos_max_cache_view_wide = wide;
	_viv_zoom_pos_max_cache_view_high = high;
	_viv_zoom_pos_max_cache_fill_window = fill_window;
	_viv_zoom_pos_max_cache_keep_aspect = config_keep_aspect_ratio;
	_viv_zoom_pos_max_cache_allow_shrinking = config_allow_shrinking;
	
	return max_pos;
}
int _viv_zoom_pos_floor(void)
{
	if (!config_allow_shrinking)
	{
		return 0;
	}
	
	return -_VIV_ZOOM_SHRINK_STEPS;
}
int _viv_clamp_zoom_pos(int zoom_pos)
{
	int pos_max;
	int pos_floor;
	
	pos_floor = _viv_zoom_pos_floor();
	
	// the below-fit floor is a constant (the extension is fit-relative), so
	// unlike the measured top there is nothing to walk: clamp straight to it.
	if (zoom_pos <= pos_floor)
	{
		return pos_floor;
	}
	
	{
		
		// the top of the ladder depends on the image, the window and the fill
		// settings (the 16x native cap), so it is measured, not hardcoded.
		pos_max = _viv_zoom_pos_max();
		
		if (zoom_pos > pos_max)
		{
			return pos_max;
		}
	}
	
	return zoom_pos;
}
static void _viv_zoom_steps(int steps,int x,int y)
{
	int cursor_x;
	int cursor_y;
	int rw;
	int rh;
	int old_rw;
	int old_rh;
	int old_cursor_px;
	int old_cursor_py;
	int wide;
	int high;
	int old_zoom_pos;
	int old_1to1;
	RECT rect;
	POINT pt;
	__int64 new_cursor_x;
	__int64 new_cursor_y;

	if (!steps)
	{
		return;
	}

	old_zoom_pos = _viv_zoom_pos;
	old_1to1 = _viv_1to1;
	GetClientRect(_viv_hwnd,&rect);
	wide = rect.right - rect.left;
	high = rect.bottom - rect.top - _viv_get_status_high() - _viv_get_view_top();
	pt.x = x;
	pt.y = y;
	ScreenToClient(_viv_hwnd,&pt);
	cursor_x = pt.x;
	cursor_y = pt.y - _viv_get_view_top();

	_viv_get_render_size(&old_rw,&old_rh);
	old_cursor_px = cursor_x - ((wide / 2) - (old_rw / 2) - _viv_view_x);
	old_cursor_py = cursor_y - ((high / 2) - (old_rh / 2) - _viv_view_y);

	if (_viv_1to1)
	{
		int lo;
		int hi;
		int pos_max;
		int use_width;

		_viv_1to1 = 0;
		lo = _viv_zoom_pos_floor();
		pos_max = _viv_zoom_pos_max();
		hi = pos_max + 1;
		use_width = (old_rw >= old_rh);

		// Search the whole live range: fill-window can put 1:1 below
		// position zero. Measure the longer axis so a one-pixel width
		// (or height) cannot hide a large scale change on the other axis.
		while (lo < hi)
		{
			int mid;
			int size;
			int old_size;

			mid = lo + ((hi - lo) / 2);
			_viv_zoom_pos = mid;
			_viv_get_render_size(&rw,&rh);
			size = use_width ? rw : rh;
			old_size = use_width ? old_rw : old_rh;
			if ((steps > 0) ? (size > old_size) : (size >= old_size))
			{
				hi = mid;
			}
			else
			{
				lo = mid + 1;
			}
		}

		// If the live ladder has no size in the requested direction,
		// stay at 1:1. Clamping an out-of-range search result could
		// otherwise enlarge on zoom-out, or shrink on zoom-in.
		if (((steps > 0) && (lo > pos_max)) || ((steps < 0) && (lo == _viv_zoom_pos_floor())))
		{
			_viv_1to1 = old_1to1;
			_viv_zoom_pos = old_zoom_pos;
			return;
		}

		// Reaching the first size in the requested direction already
		// consumes one step; apply only the remaining steps below.
		if (steps > 0)
		{
			_viv_zoom_pos = lo;
			steps--;
		}
		else
		{
			_viv_zoom_pos = lo - 1;
			steps++;
		}
	}

	_viv_zoom_pos = _viv_clamp_zoom_pos(_viv_zoom_pos + steps);
	if (old_1to1 || (_viv_zoom_pos != old_zoom_pos))
	{
		_viv_get_render_size(&rw,&rh);
		new_cursor_x = old_rw ? ((__int64)old_cursor_px * rw) / old_rw : 0;
		new_cursor_y = old_rh ? ((__int64)old_cursor_py * rh) / old_rh : 0;
		_viv_view_set((wide / 2) - (rw / 2) - cursor_x + new_cursor_x,(high / 2) - (rh / 2) - cursor_y + new_cursor_y,1);
		InvalidateRect(_viv_hwnd,0,FALSE);
		_viv_status_update_temp_pos_zoom();
	}
}
void _viv_do_mousewheel_action(int action,int delta,int x,int y)
{
	if (!delta)
	{
		return;
	}

	if (action == 0)
	{
		static int remainder = 0;
		__int64 steps;

		// Preserve sub-step input: splitting one notch into smaller
		// messages must not multiply or lose its zoom. C division keeps
		// the signed remainder, so opposite sub-step input cancels.
		steps = (__int64)delta * _VIV_ZOOM_STEPS_PER_NOTCH + remainder;
		remainder = (int)(steps % 120);
		steps /= 120;
		if (steps > _VIV_ZOOM_MAX + _VIV_ZOOM_SHRINK_STEPS)
		{
			steps = _VIV_ZOOM_MAX + _VIV_ZOOM_SHRINK_STEPS;
		}
		else
		if (steps < -(_VIV_ZOOM_MAX + _VIV_ZOOM_SHRINK_STEPS))
		{
			steps = -(_VIV_ZOOM_MAX + _VIV_ZOOM_SHRINK_STEPS);
		}
		_viv_zoom_steps((int)steps,x,y);
	}
	else
	if (action == 1)
	{
		_viv_next((delta > 0) ? 1 : 0,1,0,0);
	}
	else
	if (action == 2)
	{
		_viv_next((delta > 0) ? 0 : 1,1,0,0);
	}
}
static DWORD _viv_gesture_zoom_dist = 0; // reference distance between the two fingers.
static double _viv_gesture_zoom_ratio = 1.0; // accumulated pinch ratio since the last zoom step.
static int _viv_gesture_last_x = 0; // last two finger pan location. (screen coords)
static int _viv_gesture_last_y = 0;
static BYTE _viv_gesture_have_last = 0;

int _viv_is_touch_click(void)
{
	// The shared pen/touch signature needs bit 7 as well: 0 is pen,
	// 1 is touch. The remaining low bits identify the cursor.
	return ((GetMessageExtraInfo() & 0xFFFFFF80) == 0xFF515780) ? 1 : 0;
}
static void _viv_gesture_reset(void)
{
	_viv_gesture_zoom_dist = 0;
	_viv_gesture_zoom_ratio = 1.0;
	_viv_gesture_have_last = 0;
}
int _viv_on_gesture(HWND hwnd,void *gesture_info_handle)
{
	os_GestureInfo_t gesture_info;

	if (!os_GetGestureInfo)
	{
		return 0;
	}

	os_zero_memory(&gesture_info,sizeof(gesture_info));

	gesture_info.cbSize = sizeof(gesture_info);

	if (!os_GetGestureInfo(gesture_info_handle,&gesture_info))
	{
		return 0;
	}

	switch(gesture_info.dwID)
	{
		case 1: // GID_BEGIN
		case 2: // GID_END
			// msdn: application behavior is undefined when gid_begin and
			// gid_end are consumed. resetting the gesture state is all we need,
			// so hand the message to defwindowproc (which also owns the info
			// handle for anything we do not consume).
			if (gesture_info.dwID == 1)
			{
				// a second contact starts the gesture while the promoted
				// mouse drag can still own capture. retire that drag first.
				_viv_doing_cancel();
			}
			_viv_gesture_reset();
			return 0;

		case 3: // GID_ZOOM
		{
			DWORD dist;

			dist = (DWORD)gesture_info.ullArguments;

			// Reject zero and distances beyond the virtual screen envelope.
			// This is a defensive bound, not a Windows encoding rule.
			{
				int vw;
				int vh;

				vw = GetSystemMetrics(SM_CXVIRTUALSCREEN);
				vh = GetSystemMetrics(SM_CYVIRTUALSCREEN);

				if ((vw > 0) && (vh > 0) && ((dist == 0) || (dist > (DWORD)(vw + vh))))
				{
					// A new zoom sequence cannot inherit the previous one,
					// even when its first distance is unusable.
					if (gesture_info.dwFlags & 0x01)
					{
						_viv_gesture_zoom_dist = 0;
						_viv_gesture_zoom_ratio = 1.0;
					}
					break;
				}
			}

			// Retain the existing 36 DIP floor policy: freeze below it and
			// discard both distance and fractional steps. The next valid
			// sample re-baselines without zooming. This trades close-contact
			// response for noise suppression; the threshold needs hardware
			// validation, not an assumption that all small values are noise.
			{
				DWORD min_dist;

				min_dist = (DWORD)((36 * os_logical_wide) / 96);

				if ((dist) && (dist < min_dist))
				{
					_viv_gesture_zoom_dist = 0;
					_viv_gesture_zoom_ratio = 1.0;

					break;
				}
			}

			if (gesture_info.dwFlags & 0x01) // GF_BEGIN
			{
				_viv_gesture_zoom_dist = dist;
				_viv_gesture_zoom_ratio = 1.0;
			}
			else
			if (_viv_gesture_zoom_dist && dist)
			{
				double ratio;

				ratio = (double)dist / (double)_viv_gesture_zoom_dist;

				// Retain the existing per-message 0.5..2.0 policy. The API
				// specifies distance, not a speed bound; larger ratios alone
				// do not prove corrupt input. Revisit with a hardware trace.
				if (ratio > 2.0)
				{
					ratio = 2.0;
				}
				else
				if (ratio < 0.5)
				{
					ratio = 0.5;
				}

				_viv_gesture_zoom_ratio *= ratio;

				// convert the accumulated pinch ratio into whole 1% zoom steps and
				// apply them all in one call. the render sizes form a true
				// geometric 1.01x ladder, so the image follows the fingers.
				{
					int steps_in;
					int steps_out;

					steps_in = 0;
					steps_out = 0;

					while(_viv_gesture_zoom_ratio >= 1.01)
					{
						steps_in++;

						_viv_gesture_zoom_ratio /= 1.01;
					}

					while(_viv_gesture_zoom_ratio <= (1.0 / 1.01))
					{
						steps_out++;

						_viv_gesture_zoom_ratio *= 1.01;
					}

					if (steps_in)
					{
						_viv_zoom_steps(steps_in,gesture_info.ptsLocation.x,gesture_info.ptsLocation.y);
					}

					if (steps_out)
					{
						_viv_zoom_steps(-steps_out,gesture_info.ptsLocation.x,gesture_info.ptsLocation.y);
					}
				}
			}

			_viv_gesture_zoom_dist = dist;

			break;
		}

		case 4: // GID_PAN (two finger pan, with inertia frames)
		{
			int x;
			int y;

			x = gesture_info.ptsLocation.x;
			y = gesture_info.ptsLocation.y;

			if (gesture_info.dwFlags & 0x01) // GF_BEGIN
			{
				_viv_gesture_last_x = x;
				_viv_gesture_last_y = y;
				_viv_gesture_have_last = 1;
			}
			else
			if (_viv_gesture_have_last)
			{
				int mx;
				int my;

				mx = x - _viv_gesture_last_x;
				my = y - _viv_gesture_last_y;

				_viv_gesture_last_x = x;
				_viv_gesture_last_y = y;

				if (mx || my)
				{
					// pan the view: the image follows the fingers.
					_viv_view_scroll(mx,my);
				}
			}

			break;
		}

		case 6: // GID_TWOFINGERTAP
		{
			// reset the zoom.
			_viv_1to1 = 0;
			_viv_zoom_pos = 0;
			_viv_view_set(_viv_view_x,_viv_view_y,1);
			InvalidateRect(_viv_hwnd,0,FALSE);
			_viv_status_update_temp_pos_zoom();

			_viv_gesture_reset();

			break;
		}

		default:

			// not handled. pass to DefWindowProc.
			return 0;
	}

	// we handled the gesture. the info handle is now our responsibility.
	if (os_CloseGestureInfoHandle)
	{
		os_CloseGestureInfoHandle(gesture_info_handle);
	}

	return 1;
}

static int send(unsigned id, unsigned flags, unsigned distance)
{
    next_info.dwID = id; next_info.dwFlags = flags; next_info.ullArguments = distance;
    return _viv_on_gesture(NULL, NULL);
}
static void geometry(int iw, int ih, int cw, int ch, int fill)
{
    _viv_slot_current.image_wide = iw; _viv_slot_current.image_high = ih;
    client_wide = cw; client_high = ch;
    os_logical_wide = 96;
    config_fill_window = fill; config_allow_shrinking = 1;
    config_keep_aspect_ratio = 1; _viv_is_fullscreen = config_fullscreen_fill_window = 0;
    _viv_1to1 = _viv_zoom_pos = _viv_view_x = _viv_view_y = _viv_doing = 0;
    invalidated = status_updates = navigated = 0;
    _viv_gesture_reset();
}
static void policy(void)
{
    int dpi;
    for (dpi = 96; dpi <= 288; dpi += 96)
    {
        unsigned floor = 36 * dpi / 96;
        os_logical_wide = dpi;
        _viv_gesture_reset();
        _viv_gesture_zoom_ratio = 1.009;
        assert(send(3, 1, floor - 1) == 1);
        assert(_viv_gesture_zoom_dist == 0 && _viv_gesture_zoom_ratio == 1.0);
        _viv_zoom_pos = 0;
        send(3, 0, floor); /* first valid sample establishes a baseline */
        assert(!_viv_zoom_pos && _viv_gesture_zoom_dist == floor);
        send(3, 0, floor * 11 / 10);
        assert(_viv_zoom_pos > 0);
        _viv_gesture_zoom_ratio = 1.008;
        send(3, 0, floor - 1);
        assert(_viv_gesture_zoom_ratio == 1.0);
    }
    _viv_doing = captured = 1;
    closed = 0;
    assert(send(1, 0, 0) == 0); /* DefWindowProc owns BEGIN and END handles */
    assert(!_viv_doing && !captured && !closed);
    assert(send(2, 0, 0) == 0 && !closed);
    assert(send(999, 0, 0) == 0 && !closed);
    assert(send(3, 1, 100) == 1 && closed == 1);

    geometry(4000, 3000, 1600, 1000, 0);
    send(3, 1, 20); send(3, 0, 30);
    assert(!_viv_zoom_pos); /* current policy: sub-floor input is frozen */
    send(3, 0, 100); assert(!_viv_zoom_pos);
    send(3, 0, 150);
    assert(_viv_zoom_pos >= 40 && _viv_zoom_pos <= 41); /* a real 1.5x distance change */
    puts("gesture policy: floor/rebase, ratio, DPI, drag cancellation and handle ownership passed");
}
/* A linear walk through the real renderer is independent of the binary
   search used by the action. The native image's longer axis avoids a
   one-pixel width hiding a large change in a tall image (and vice versa). */
static int first_position(int direction)
{
    int pos, first = 0, found = 0, rw, rh;
    _viv_1to1 = 0;
    for (pos = _viv_zoom_pos_floor(); pos <= _viv_zoom_pos_max(); pos++)
    {
        int actual, native;
        _viv_zoom_pos = pos;
        _viv_get_render_size(&rw, &rh);
        actual = _viv_slot_current.image_wide >= _viv_slot_current.image_high ? rw : rh;
        native = _viv_slot_current.image_wide >= _viv_slot_current.image_high ? _viv_slot_current.image_wide : _viv_slot_current.image_high;
        if ((direction > 0 && actual > native) || (direction < 0 && actual < native))
        {
            first = pos; found = 1;
            if (direction > 0) break;
        }
    }
    assert(found);
    return first;
}
static void zoom(void)
{
    const int images[][5] = {
        {4000, 3000, 1600, 1000, 0},
        {800, 600, 1600, 1200, 1}, /* fit is larger than 1:1 */
        {1, 4000, 1600, 1000, 0},
        {4000, 1, 1600, 1000, 0},
    };
    unsigned i;
    int direction, notch;
    for (i = 0; i < sizeof(images) / sizeof(images[0]); i++)
        for (direction = -1; direction <= 1; direction += 2)
            for (notch = 0; notch <= 1; notch++)
            {
                int steps = notch ? _VIV_ZOOM_STEPS_PER_NOTCH : 1;
                int delta = notch ? 120 : (120 + _VIV_ZOOM_STEPS_PER_NOTCH - 1) / _VIV_ZOOM_STEPS_PER_NOTCH;
                int expected;
                geometry(images[i][0], images[i][1], images[i][2], images[i][3], images[i][4]);
                expected = _viv_clamp_zoom_pos(first_position(direction) + direction * (steps - 1));
                _viv_1to1 = 1;
                _viv_zoom_pos = expected; /* stale position must not suppress redraw */
                _viv_do_mousewheel_action(0, direction * delta, client_wide / 2, client_high / 2);
                fprintf(stderr, "1:1 image %u direction %d steps %d: position %d expected %d\n", i, direction, steps, _viv_zoom_pos, expected);
                assert(!_viv_1to1 && _viv_zoom_pos == expected);
                assert(invalidated == 1 && status_updates == 1);
            }
    geometry(4000, 3000, 1600, 1000, 0);
    _viv_do_mousewheel_action(0, 120, 800, 500);
    assert(_viv_zoom_pos == _VIV_ZOOM_STEPS_PER_NOTCH);
    _viv_do_mousewheel_action(0, -120, 800, 500);
    assert(!_viv_zoom_pos);
    puts("zoom: 1:1 single/notch steps, below-fit mapping, thin images and redraw passed");
}
static void zero(void)
{
    geometry(4000, 3000, 1600, 1000, 0);
    _viv_1to1 = 1; _viv_zoom_pos = 42;
    _viv_do_mousewheel_action(0, 0, 800, 500);
    assert(_viv_1to1 && _viv_zoom_pos == 42 && !invalidated && !status_updates);
    _viv_do_mousewheel_action(1, 0, 800, 500);
    assert(!navigated);
    _viv_do_mousewheel_action(2, 0, 800, 500);
    assert(!navigated);
    puts("zoom: zero wheel delta is a no-op");
}
static void begin(void)
{
    const unsigned invalid[] = {0, 9000};
    unsigned i;
    for (i = 0; i < sizeof(invalid) / sizeof(invalid[0]); i++)
    {
        geometry(4000, 3000, 1600, 1000, 0);
        send(3, 1, 1000); send(3, 0, 1100);
        _viv_gesture_zoom_ratio = 1.009;
        send(3, 1, invalid[i]);
        assert(!_viv_gesture_zoom_dist && _viv_gesture_zoom_ratio == 1.0);
        invalidated = 0;
        send(3, 0, 100); /* the new gesture cannot reuse the old distance */
        assert(!invalidated && _viv_gesture_zoom_dist == 100);
    }
    puts("gesture: invalid per-type BEGIN cannot keep a stale baseline");
}
static void touch(void)
{
    message_extra = 0; assert(!_viv_is_touch_click());
    message_extra = 0xff515701u; assert(!_viv_is_touch_click()); /* pen */
    message_extra = 0xff515780u; assert(_viv_is_touch_click());
    message_extra = 0xff5157ffu; assert(_viv_is_touch_click());
    message_extra = 0x12340080u; assert(!_viv_is_touch_click());
    puts("input: mouse, pen and promoted touch signatures passed");
}
static void wheel(void)
{
    const int parts[] = {1, 12, 40};
    int direction;
    unsigned p;
    for (direction = -1; direction <= 1; direction += 2)
        for (p = 0; p < sizeof(parts) / sizeof(parts[0]); p++)
        {
            int i, expected, part = parts[p];
            geometry(4000, 3000, 1600, 1000, 0);
            expected = direction * _VIV_ZOOM_STEPS_PER_NOTCH;
            for (i = 0; i < 120 / part; i++)
                _viv_do_mousewheel_action(0, direction * part, 800, 500);
            fprintf(stderr, "wheel direction %d partition %d: position %d expected %d\n", direction, part, _viv_zoom_pos, expected);
            assert(_viv_zoom_pos == expected);
        }
    geometry(4000, 3000, 1600, 1000, 0);
    _viv_do_mousewheel_action(0, 1, 800, 500);
    _viv_do_mousewheel_action(0, -1, 800, 500);
    assert(!_viv_zoom_pos && !invalidated);
    puts("wheel: partition-independent scaling and sub-step reversal passed");
}
static void bounds(void)
{
    int shrink;
    for (shrink = 0; shrink <= 1; shrink++)
    {
        geometry(1, 1, 1000, 1000, 1);
        config_allow_shrinking = shrink;
        _viv_1to1 = 1; _viv_zoom_pos = 42;
        _viv_do_mousewheel_action(0, -120, 500, 500);
        assert(_viv_1to1 && _viv_zoom_pos == 42 && !invalidated);
    }
    geometry(800, 600, 1600, 1200, 1);
    config_allow_shrinking = 0;
    _viv_1to1 = 1; _viv_zoom_pos = 42;
    _viv_do_mousewheel_action(0, -120, 800, 600);
    assert(_viv_1to1 && _viv_zoom_pos == 42 && !invalidated);
    geometry(4000, 1, 1600, 1000, 1);
    config_keep_aspect_ratio = 0;
    _viv_1to1 = 1; _viv_zoom_pos = 42;
    _viv_do_mousewheel_action(0, 120, 800, 500);
    assert(_viv_1to1 && _viv_zoom_pos == 42 && !invalidated);
    puts("zoom: an unavailable ladder size cannot reverse the requested direction");
}

int main(void) {
    const int dims[][4]={{1,1,1600,1000},{800,600,1600,1200},{4000,3000,1600,1000},{1,4000,1600,1000},{4000,1,1600,1000},{1000000,1,10,10},{1234,777,1,1},{200,400,1920,1080}};
    const int counts[]={-1302,-120,-10,-1,1,10,120,1302};
    int a,f,k,s,fs,j,checked=0;
    init_scales();
    for(a=0;a<8;a++) for(f=0;f<2;f++) for(k=0;k<2;k++) for(s=0;s<2;s++) for(fs=0;fs<2;fs++) for(j=0;j<8;j++) {
        int top,floor,pos,rw,rh,found=0,candidate=0,native,actual,expected;
        geometry(dims[a][0],dims[a][1],dims[a][2],dims[a][3],f);
        config_keep_aspect_ratio=k; config_allow_shrinking=s;
        _viv_is_fullscreen=fs; config_fullscreen_fill_window=1-f;
        top=_viv_zoom_pos_max(); floor=_viv_zoom_pos_floor();
        native=dims[a][0]>=dims[a][1]?dims[a][0]:dims[a][1];
        for(pos=floor;pos<=top;pos++) {
            _viv_zoom_pos=pos; _viv_get_render_size(&rw,&rh);
            actual=dims[a][0]>=dims[a][1]?rw:rh;
            if((counts[j]>0 && actual>native)||(counts[j]<0 && actual<native)) {
                candidate=pos; found=1; if(counts[j]>0) break;
            }
        }
        expected=found?_viv_clamp_zoom_pos(candidate+counts[j]-(counts[j]>0?1:-1)):42;
        _viv_1to1=1; _viv_zoom_pos=42;
        _viv_zoom_steps(counts[j],dims[a][2]/3,dims[a][3]/4);
        if(_viv_zoom_pos!=expected || _viv_1to1!=!found || invalidated!=found || status_updates!=found) {
            fprintf(stderr,"mismatch image=%d fill=%d keep=%d shrink=%d fullscreen=%d steps=%d got mode%d/pos%d/redraw%d expected mode%d/pos%d/redraw%d\n",a,f,k,s,fs,counts[j],_viv_1to1,_viv_zoom_pos,invalidated,!found,expected,found);
            return 2;
        }
        checked++;
    }
    printf("Expanded real C 1:1 matrix: %d cases passed\n",checked);
    return 0;
}
